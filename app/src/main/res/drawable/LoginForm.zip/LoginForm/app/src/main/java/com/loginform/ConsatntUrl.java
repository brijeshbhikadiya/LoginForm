package com.loginform;

public class ConsatntUrl {

    public static  final String URL="https://brijeshbhikadiya.000webhostapp.com/bunty/";
    public static final String SIGNUP_URL= URL+"signup.php";
    public static final String LOGIN_URL= URL+"login.php";
    public static final String UPDATE_URL= URL+"update.php";





    public static final String PREF = "pref";

    public static final String ID = "id";
    public static final String Name = "name";
    public static final String EmailID = "emailid";
    public static final String Contact = "contact";
    public static final String Gender = "gender";
    public static final String City = "city";
    public static final String Dob = "dob";
    public static final String Type = "type";



}
